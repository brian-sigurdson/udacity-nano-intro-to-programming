weapons = ['samurai sword', 'cannon', 'pistol', 'tank', 'battleship']

monsters = ['vampire', 'mummy', 'ghost', 'alien', 'slime monster']
